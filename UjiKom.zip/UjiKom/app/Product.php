<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = "products";
    protected $fillable = ['name_product','price','stock', 'descripsi','photo'];
    protected $id = 'id';
    public function transaction_detail()
    {
        return $this->hasMany('App\transactionDetail','product_id','id');
    }
}
