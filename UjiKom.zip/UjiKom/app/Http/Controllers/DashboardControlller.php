<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardControlller extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','verified']);
    }

    public function index()
    {
        if (Auth::check()) {
            if (Auth::user()->role == 'admin') {
                return view('menu.index');
            } elseif (Auth::user()->role == 'user') {
                $products = Product::all();
                return view('user', compact('products'));
            } else {
                abort(404, 'Tampilan dengan Role ' . Auth::user()->role . ' tidak ada');
            }
        } else {
            // Redirect to login or handle unauthenticated user
            return redirect()->route('login');
        }
    }

    public function search(Request $request){
        $search = $request->search;
        $products = DB::table('products')->where('name_product', 'like', "%" . $search . "%")->paginate();
        return view('user', compact('products'));

    }
}
