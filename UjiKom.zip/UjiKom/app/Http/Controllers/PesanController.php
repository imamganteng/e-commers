<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\transaction;
use App\User;
use App\transactionDetail;
use Alert;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class PesanController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index($id)
    {
        $products = Product::where('id', $id)->first();
        return view('pesan.index', compact('products'));
    }

    public function order(Request $request, $id)
    {
        $products = Product::where('id', $id)->first();
        $tanggal = Carbon::now();

        //validate whether it exceeds stock 
        if ($request->jumlah_pesan > $products->stock) {
            return redirect('order/' . $id);
        }

        //check validation
        $check_transaction = transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
        //simpan ke database pesanan
        if (empty($check_transaction)) {
            //save to database transaction
            $transactions = new transaction;
            $transactions->user_id = Auth::user()->id;
            $transactions->tanggal = $tanggal;
            $transactions->status = 0;
            $transactions->jumlah_harga = 0;
            $transactions->kode = mt_rand(100,999);
            $transactions->save();
        }

        //save to database transaction Detail
        $transactionNew = transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();

        //check transaction detail
        $check_transactionDetail = transactionDetail::where('product_id', $products->id)->where('transaction_id', $transactionNew->id)->first();
        if (empty($check_transactionDetail)) {
            $transactionDetails = new transactionDetail;
            $transactionDetails->product_id = $products->id;
            $transactionDetails->transaction_id = $transactionNew->id;
            $transactionDetails->jumlah = $request->jumlah_pesan;
            $transactionDetails->jumlah_harga = $products->price * $request->jumlah_pesan;
            $transactionDetails->save();
        } else {
            $transactionDetails = transactionDetail::where('product_id', $products->id)->where('transaction_id', $transactionNew->id)->first();

            $transactionDetails->jumlah = $transactionDetails->jumlah += $request->jumlah_pesan;

            //price now
            $price_transaction_detail_new = $products->price * $request->jumlah_pesan;
            $transactionDetails->jumlah_harga = $transactionDetails->jumlah_harga + $price_transaction_detail_new;
            $transactionDetails->update();
        }
        //total number
        $transactions = transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
        $transactions->jumlah_harga = $transactions->jumlah_harga + $products->price * $request->jumlah_pesan;
        $transactions->update();
        alert()->success('Success', 'The product has been successfully added to the cart.');
        return redirect('/check-out');
    }

    public function check_out()
    {
        $transactions = transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
        $transactionDetails = [];
        if (!empty($transactions)) {
            $transactionDetails = transactionDetail::where('transaction_id', $transactions->id)->get();
        }
        return view('pesan.check_out', compact('transactions', 'transactionDetails'));
    }

    public function delete($id)
    {
        $transactionDetails = transactionDetail::where('id', $id)->first();
        $transactions = transaction::where('id', $transactionDetails->transaction_id)->first();
        $transactions->jumlah_harga = $transactions->jumlah_harga - $transactionDetails->jumlah_harga;
        $transactions->update();
        $transactionDetails->delete();
        alert()->error('Delete', 'Order successfully deleted');
        return redirect('check-out');
    }

    public function confirm()
    {
        $transactions = transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
        $transactions_id = $transactions->id;
        $transactions->status = 1;
        $transactions->update();
        $transactionsDetails = transactionDetail::where('transaction_id', $transactions_id)->get();
        foreach ($transactionsDetails as $transactionsDetail) {
            $products = Product::where('id', $transactionsDetail->product_id)->first();
            $products->stock = $products->stock - $transactionsDetail->jumlah;
            $products->update();
        }
        alert()->success('Success', 'Order successfully checked out.');
        return redirect('check-out');
    }
}
