<?php

namespace App\Http\Controllers;

use App\transaction;
use App\transactionDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HistoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $transactions = transaction::where('user_id', Auth::user()->id)->where('status', '!=', 0)->get();
        return view('history.index', compact('transactions'));
    }

    public function detail($id)
    {
        $transactions = transaction::where('id', $id)->first();
        $transactionsDetails = transactionDetail::where('transaction_id', $transactions->id)->get();

        return view('history.detail', compact('transactions', 'transactionsDetails'));
    }

    public function tampil()
    {
        $transactions = transaction::all();
        return view('history.lihat', compact('transactions'));
    }

    public function edit($id)
    {
        $transactions = transaction::find($id);
        return view('history.edit', compact('transactions'));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'status' => 'required',
        ]);
        $transactions = transaction::find($id);
        $transactions->status = $request->status;
        $transactions->save();
        return redirect('/tampil');
    }

    public function create($id){
        $transactions = transaction::find($id);
        return view('history.payment',compact('transactions'));
    }
    public function upload(Request $request, $id)
    {
        $this->validate($request, [
            'photo' => 'required',
        ]);
        $transactions = transaction::find($id);
        $imgName = $request->photo->getClientOriginalName() . '-' . time() . '.' . $request->photo->extension();
        $request->photo->move(public_path('image'), $imgName);
        $transactions->photo = $imgName;
        $transactions->save();
        return redirect('history');
    }
}
