<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transaction extends Model
{
    public function user()
    {
        return $this->belongsTo('App\User','user_id','id');
    }

    public function transaction_detail()
    {
        return $this->belongsTo('App\transactionDetail', 'transaction_id', 'id');
    }
}
