<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', 'HomeController@index')->name('product.index');
// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes(['verify' => true]);
Route::get('profile', function () {
})->middleware('verified');
Route::get('/dashboard', 'DashboardControlller@index')->name('dashboard')->middleware('verified');
Route::get('/search', 'DashboardControlller@search')->name('search')->middleware('verified');

//Product
Route::get('/product', 'ProductController@index')->name('product.index');
Route::get('/product/create', 'ProductController@create')->name('product.create');
Route::post('/product', 'ProductController@store')->name('product.store');
Route::get('/product/edit/{id}', 'ProductController@edit')->name('product.edit');
Route::put('/product/{id}', 'ProductController@update')->name('product.update');
Route::get('/product/{id}', 'ProductController@destroy')->name('product.destroy');

//order
Route::get('order/{id}', 'PesanController@index')->name('pesan.index');
Route::post('order/{id}', 'PesanController@order');
Route::get('check-out', 'PesanController@check_out');
Route::delete('check-out/{id}', 'PesanController@delete');
Route::ge('confirm-check-out', "PesanController@confirm")->name('confirm-check-out');
Route::get('/profile', 'ProfileController@index');

Route::get('history', 'HistoryController@index');
Route::get('payment_proof/{id}', 'HistoryController@create');
Route::put('upload/{id}', 'HistoryController@upload')->name('history.upload');
Route::get('history/detail/{id}', 'HistoryController@detail');
Route::get('history/edit/{id}', 'HistoryController@edit');
Route::put('history/{id}', 'HistoryController@update')->name('transaction.update');
Route::get('tampil', 'HistoryController@tampil');

