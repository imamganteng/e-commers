<?php

use Illuminate\Database\Seeder;
use App\User;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Administrator',
            'email' => 'imam@gmail.com',
            'password' => bcrypt('admin'),
            'email_verified_at' => now(),
            'address' => "jl.h muhajir bawah",
            'phone' => "087738117156",
            'role' => "Admin"
        ]);
    }
}
