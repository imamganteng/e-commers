<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Riwayat Pemesanan</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card col-md-12">
                <div class="card-body">
                    <h3><i class="fa fa-history"></i> Riwayat Pemesanan</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Jumlah Harga</th>
                                <th>Bukti Transfer</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($transaction->tanggal); ?></td>
                                <td>
                                    <?php if($transaction->status == 1): ?>
                                    Sudah Pesan & Belum dibayar
                                    <?php else: ?>
                                    Sudah dibayar 
                                    <?php endif; ?>
                                </td>
                                <td>Rp. <?php echo e(number_format($transaction->jumlah_harga+$transaction->kode)); ?></td>
                                <td>
                                     <?php if($transaction->photo): ?>
                                        <img src="<?php echo e(asset('image/'. $transaction->photo)); ?>" height="150" width="150" alt="">
                                    <?php else: ?>
                                        Pelanggan Belum Bayar
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('history/edit')); ?>/<?php echo e($transaction->id); ?>" class="btn btn-success"><i class="fa fa-info"></i> Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\UjiKom\resources\views/history/lihat.blade.php ENDPATH**/ ?>