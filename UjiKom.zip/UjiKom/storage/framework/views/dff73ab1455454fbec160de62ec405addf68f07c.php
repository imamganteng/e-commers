<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Check Out</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3><i class="fa fa-shopping-cart"></i> Check Out</h3>
                    <?php if(!empty($transactions)): ?>
                    <p align="right">Tanggal Pesan : <?php echo e($transactions->tanggal); ?></p>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Pilih</th>
                                    <th>Gambar</th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah</th>
                                    <th>Harga</th>
                                    <th>Total Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $transactionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <input type="checkbox" class="product-checkbox" name="selected_transactions[]" value="<?php echo e($transaction_detail->id); ?>">
                                    </td>
                                    <td>
                                        <img src="<?php echo e(asset('image/'. $transaction_detail->product->photo)); ?>" width="100" alt="...">
                                    </td>
                                    <td><?php echo e($transaction_detail->product->name_product); ?></td>
                                    <td>
                                        <input type="number" value="<?php echo e($transaction_detail->jumlah); ?>"  class="quantity" style="width: 50px">
                                    </td>
                                    <td align="" class="product-price" data-price="<?php echo e($transaction_detail->product->price); ?>">Rp. <?php echo e(number_format($transaction_detail->product->price)); ?></td>
                                    <td align="" class="total-uang">Rp. <?php echo e(number_format($transaction_detail->jumlah_harga)); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="deleteItem(<?php echo e($transaction_detail->id); ?>)">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="5" align="right"><strong>Total Harga :</strong></td>
                                    <td align="right" class="total-harga"><strong>Rp. 0</strong></td>
                                    <td>
                                        <button type="button" class="btn btn-success btn-checkout">
                                            <i class="fa fa-shopping-cart"></i> Check Out
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('.quantity').on('input', function() {
            var quantity = $(this).val();
            var productPrice = $(this).closest('tr').find('.product-price').data('price');
            var totalHarga = quantity * productPrice;
            $(this).closest('tr').find('.total-uang').text('Rp. ' + numberWithCommas(totalHarga));
        });
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    });
</script>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        var totalHargaSebelumnya = 0;
        $('.quantity').on('input', function() {
            var quantity = $(this).val();
            var productPrice = $(this).closest('tr').find('.product-price').data('price');
            var totalHarga = quantity * productPrice;
            $(this).closest('tr').find('.total-harga').text('Rp. ' + numberWithCommas(totalHarga));
            updateTotalHarga();
        });
        $('.product-checkbox').on('change', function() {
            updateTotalHarga();
        });
        function updateTotalHarga() {
            var totalHarga = 0;
            var adaProdukTerpilih = false;
            $('.product-checkbox:checked').each(function() {
                adaProdukTerpilih = true;
                var quantity = $(this).closest('tr').find('.quantity').val();
                var productPrice = $(this).closest('tr').find('.product-price').data('price');
                totalHarga += quantity * productPrice;
            });
            if (!adaProdukTerpilih) {
                totalHarga = 0;
            }
            $('.total-harga').text('Rp. ' + numberWithCommas(totalHarga));
        }
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    });
</script>
<script>
    $(document).ready(function() {
        $('.btn-checkout').on('click', function(e) {
            e.preventDefault();
            var checkedProducts = $('.product-checkbox:checked');

            if (checkedProducts.length === 0) {
                alert('Pilih setidaknya satu produk untuk Check Out.');
            } else {
                // Collect the IDs of the checked products
                var productIds = [];
                checkedProducts.each(function() {
                    productIds.push($(this).val());
                });

                // Generate the URL with productIds
                var checkoutUrl = "<?php echo e(url('confirm-check-out')); ?>?productIds=" + productIds.join(',');

                // Redirect to the checkout page with selected productIds
                window.location.href = checkoutUrl;
            }
        });
    });
</script>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\UjiKom\resources\views/pesan/check_out.blade.php ENDPATH**/ ?>