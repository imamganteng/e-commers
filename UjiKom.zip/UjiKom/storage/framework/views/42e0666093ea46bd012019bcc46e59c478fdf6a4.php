<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <strong>Edit Data</strong>
            </div>
            <form method="post" action="<?php echo e(route('product.update', $product->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="name_product" class="form-control" placeholder="Nama .." value="<?php echo e($product->name_product); ?>">
                    <?php if($errors->has('name_product')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('name_product')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="text" name="price" class="form-control" placeholder="Price" value="<?php echo e($product->price); ?>">
                    <?php if($errors->has('price')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                            <label>stock</label>
                            <input type="number" name="stock" class="form-control" placeholder="stock" value="<?php echo e($product->stock); ?>">
                             <?php if($errors->has('stock')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('stock')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                <div class="form-group">
                    <label>Descripsi</label>
                    <textarea name="descripsi" class="form-control" placeholder="Isi descripsi"><?php echo e($product->descripsi); ?></textarea>
                    <?php if($errors->has('descripsi')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('descripsi')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                            <label>photo</label>
                            <input type="file" name="photo" class="form-control" placeholder="photo">
                            <?php if($errors->has('photo')): ?>
                                <div class="file-danger">
                                    <?php echo e($errors->first('photo')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\UjiKom\resources\views/product/edit.blade.php ENDPATH**/ ?>