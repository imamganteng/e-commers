<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mb-5">
            <img src="<?php echo e(url('images/logo.png')); ?>" class="rounded mx-auto d-block" width="700" alt="">
        </div>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4 ml-auto">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset('image/'. $product->photo)); ?>" alt="Card image cap" width="350" height="350">
                        <div class="card-body">
                            <h5 class="card-title"><strong><?php echo e($product->name_product); ?></strong></h5>
                            <p class="card-text">
                                <strong>Price : </strong> Rp. <?php echo e(number_format($product->price)); ?> <br>
                                <strong>Stock : </strong><?php echo e($product->stock); ?> <br>
                                <hr>
                                <strong>Descripsi : </strong><br>
                                <?php echo e($product->descripsi); ?>

                            </p>
                            <a href="<?php echo e(url('order')); ?>/<?php echo e($product->id); ?>" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Order</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\UjiKom\resources\views/user.blade.php ENDPATH**/ ?>