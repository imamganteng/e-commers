<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <strong>Edit Data</strong>
            </div>
            <form method="post" action="<?php echo e(route('transaction.update', $transactions->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="status" class="form-control" placeholder="Nama .." value="<?php echo e($transactions->status); ?>">
                    <?php if($errors->has('status')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                    <a href="<?php echo e(url('tampil')); ?>" class="btn btn-primary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\UjiKom\resources\views/history/edit.blade.php ENDPATH**/ ?>