<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\UjiKom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>