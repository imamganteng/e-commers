<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <strong>Upload Bukti Pembayaran</strong>
            </div>
            <form method="post" action="<?php echo e(route('history.upload', $transactions->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <div class="form-group">
                            <label>photo</label>
                            <input type="file" name="photo" class="form-control" placeholder="photo">
                            <?php if($errors->has('photo')): ?>
                                <div class="file-danger">
                                    <?php echo e($errors->first('photo')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                    <a href="<?php echo e(url('history')); ?>" class="btn btn-primary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\UjiKom\resources\views/history/payment.blade.php ENDPATH**/ ?>