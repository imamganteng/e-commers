<?php $__env->startSection('main'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Product</h6>
        </div>
        <div class="card-body">
            <a href="/product/create" class="btn btn-primary">Input Data Barang</a>
            <div class="table-responsive">
                <table class="table table-bordered mt-3" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name Product</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Descripsi</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Descripsi</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i+1); ?></td>
                            <td><?php echo e($p->name_product); ?></td>
                            <td><?php echo e($p->price); ?></td>
                            <td><?php echo e($p->stock); ?></td>
                            <td><?php echo e($p->descripsi); ?></td>
                            <td><img src="<?php echo e(asset('image/'. $p->photo)); ?>" height="100" width="100" alt=""></td>
                            <td>
                                <a href="/product/edit/<?php echo e($p->id); ?>" class="btn btn-warning btn-sm mb-2">Edit</a>
                                <a href="/product/<?php echo e($p->id); ?>" class="btn btn-danger btn-sm">Hapus</a>
                                <a href="/product/detail/<?php echo e($p->id); ?>" class="btn btn-success mt-3 btn-sm">Detail</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\UjiKom\resources\views/product/index.blade.php ENDPATH**/ ?>