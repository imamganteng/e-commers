@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="{{ url('dashboard') }}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Check Out</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3><i class="fa fa-shopping-cart"></i> Check Out</h3>
                    @if(!empty($transactions))
                    <p align="right">Tanggal Pesan : {{ $transactions->tanggal }}</p>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Pilih</th>
                                    <th>Gambar</th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah</th>
                                    <th>Harga</th>
                                    <th>Total Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                @foreach($transactionDetails as $transaction_detail)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>
                                        <input type="checkbox" class="product-checkbox" name="selected_transactions[]" value="{{ $transaction_detail->id }}">
                                    </td>
                                    <td>
                                        <img src="{{ asset('image/'. $transaction_detail->product->photo) }}" width="100" alt="...">
                                    </td>
                                    <td>{{ $transaction_detail->product->name_product }}</td>
                                    <td>
                                        <input type="number" value="{{ $transaction_detail->jumlah }}"  class="quantity" style="width: 50px">
                                    </td>
                                    <td align="" class="product-price" data-price="{{ $transaction_detail->product->price }}">Rp. {{ number_format($transaction_detail->product->price) }}</td>
                                    <td align="" class="total-uang">Rp. {{ number_format($transaction_detail->jumlah_harga) }}</td>
                                    <td>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="deleteItem({{ $transaction_detail->id }})">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                @endforeach
                                <tr>
                                    <td colspan="5" align="right"><strong>Total Harga :</strong></td>
                                    <td align="right" class="total-harga"><strong>Rp. 0</strong></td>
                                    <td>
                                        <button type="button" class="btn btn-success">
                                            <i class="fa fa-shopping-cart"></i> Check Out
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

{{-- total harga product --}}
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('.quantity').on('input', function() {
            var quantity = $(this).val();
            var productPrice = $(this).closest('tr').find('.product-price').data('price');
            var totalHarga = quantity * productPrice;
            $(this).closest('tr').find('.total-uang').text('Rp. ' + numberWithCommas(totalHarga));
        });
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    });
</script>

{{-- cekrek cekrek --}}

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        var totalHargaSebelumnya = 0;
        $('.quantity').on('input', function() {
            var quantity = $(this).val();
            var productPrice = $(this).closest('tr').find('.product-price').data('price');
            var totalHarga = quantity * productPrice;
            $(this).closest('tr').find('.total-harga').text('Rp. ' + numberWithCommas(totalHarga));
            updateTotalHarga();
        });
        $('.product-checkbox').on('change', function() {
            updateTotalHarga();
        });
        function updateTotalHarga() {
            var totalHarga = 0;
            var adaProdukTerpilih = false;
            $('.product-checkbox:checked').each(function() {
                adaProdukTerpilih = true;
                var quantity = $(this).closest('tr').find('.quantity').val();
                var productPrice = $(this).closest('tr').find('.product-price').data('price');
                totalHarga += quantity * productPrice;
            });
            if (!adaProdukTerpilih) {
                totalHarga = 0;
            }
            $('.total-harga').text('Rp. ' + numberWithCommas(totalHarga));
        }
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    });
</script>





