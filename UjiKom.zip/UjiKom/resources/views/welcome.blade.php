            @extends('layouts.app')
        <div class="flex-center position-ref full-height">
            @section('content')
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12 mb-5">
                        <img src="{{url('images/logo.png')}}" class="rounded mx-auto d-block" width="700" alt="">
                    </div>
                    <div class="row">
                        @foreach ($products as $product)
                            <div class="col-md-4 mb-4 ml-auto">
                                <div class="card" style="width: 18rem;">
                                    <img class="card-img-top" src="{{ asset('image/'. $product->photo) }}" alt="Card image cap" width="350" height="350">
                                    <div class="card-body">
                                        <h5 class="card-title"><strong>{{ $product->name_product }}</strong></h5>
                                        <p class="card-text">
                                            <strong>Price : </strong> Rp. {{ number_format($product->price)}} <br>
                                            <strong>Stock : </strong>{{$product->stock}} <br>
                                            <hr>
                                            <strong>Descripsi : </strong><br>
                                            {{ $product->descripsi }}
                                        </p>
                                        <a href="{{url('order')}}/{{$product->id}}" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Order</a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
            @endsection
        </div>
