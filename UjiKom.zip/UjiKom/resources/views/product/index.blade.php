@extends('menu.index')
@section('main')
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Product</h6>
        </div>
        <div class="card-body">
            <a href="/product/create" class="btn btn-primary">Input Data Barang</a>
            <div class="table-responsive">
                <table class="table table-bordered mt-3" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name Product</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Descripsi</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Descripsi</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        @foreach($products as $i => $p)
                        <tr>
                            <td>{{ $i+1 }}</td>
                            <td>{{ $p->name_product }}</td>
                            <td>{{ $p->price }}</td>
                            <td>{{ $p->stock }}</td>
                            <td>{{ $p->descripsi }}</td>
                            <td><img src="{{ asset('image/'. $p->photo) }}" height="100" width="100" alt=""></td>
                            <td>
                                <a href="/product/edit/{{ $p->id }}" class="btn btn-warning btn-sm mb-2">Edit</a>
                                <a href="/product/{{ $p->id }}" class="btn btn-danger btn-sm">Hapus</a>
                                <a href="/product/detail/{{ $p->id }}" class="btn btn-success mt-3 btn-sm">Detail</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection