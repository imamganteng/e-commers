@extends('menu.index')
@section('main')
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                   <strong>Tambah Data</strong>  
                </div>
                    <form method="post" action="{{route('product.store')}}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="name_product" class="form-control" placeholder="Nama ..">
                            @if($errors->has('name_product'))
                                <div class="text-danger">
                                    {{ $errors->first('name_product')}}
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label>price</label>
                            <input type="text" name="price" class="form-control" placeholder="price">
                            @if($errors->has('price'))
                                <div class="text-danger">
                                    {{ $errors->first('price')}}
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label>stock</label>
                            <input type="number" name="stock" class="form-control" placeholder="stock">
                             @if($errors->has('stock'))
                                <div class="text-danger">
                                    {{ $errors->first('stock')}}
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label>photo</label>
                            <input type="file" name="photo" class="form-control" placeholder="photo">
                            @if($errors->has('photo'))
                                <div class="file-danger">
                                    {{ $errors->first('photo')}}
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label>Descripsi</label>
                            <textarea name="descripsi" class="form-control" placeholder="Isi Deskripsi"></textarea>
                             @if($errors->has('descripsi'))
                                <div class="text-danger">
                                    {{ $errors->first('descripsi')}}
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                            <a href="/product" class="btn btn-primary">Kembali</a>
                        </div>
                </div>
            </div>
        </div>
@endsection