@extends('menu.index')
@section('main')
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <strong>Edit Data</strong>
            </div>
            <form method="post" action="{{ route('transaction.update', $transactions->id) }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="status" class="form-control" placeholder="Nama .." value="{{ $transactions->status}}">
                    @if($errors->has('status'))
                    <div class="text-danger">
                        {{ $errors->first('status') }}
                    </div>
                    @endif
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                    <a href="{{ url('tampil') }}" class="btn btn-primary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
@endsection