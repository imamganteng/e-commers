@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <strong>Upload Bukti Pembayaran</strong>
            </div>
            <form method="post" action="{{ route('history.upload', $transactions->id) }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <div class="form-group">
                            <label>photo</label>
                            <input type="file" name="photo" class="form-control" placeholder="photo">
                            @if($errors->has('photo'))
                                <div class="file-danger">
                                    {{ $errors->first('photo')}}
                                </div>
                            @endif
                        </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                    <a href="{{ url('history') }}" class="btn btn-primary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
@endsection